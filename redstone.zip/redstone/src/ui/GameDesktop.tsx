import { useEffect, useRef, useState } from 'react'
import type { LevelRun } from '../game/sim'
import type { Dir, Level } from '../game/types'
import { Board } from './Board'
import { clampZoom, zoomAround, type Camera, type Viewport } from './camera'
import { Inspector } from './Inspector'
import { GoalDialog } from './GoalDialog'
import { Handbook } from './Handbook'
import {
  CheckIcon,
  CrossIcon,
  DotsIcon,
  ExitIcon,
  InfoIcon,
  Logo,
  MenuIcon,
  PauseIcon,
  PlayIcon,
  PrevIcon,
  StepIcon,
} from './icons'
import { previewDirOf, type Tool } from './tools'
import type { EditMode } from './edit-mode'
import { selectionActionForKey, type Clipboard, type Selection } from './selection'
import { isTypingTarget } from './keyboard'
import type { TraceInfo } from './trace'
import type { WaveSample } from './waveform'
import { padNo } from './levels-meta'

interface Props {
  level: Level
  /** 自由模式：没有关卡号、端口和测试，相关入口收起来 */
  free: boolean
  /** 这次进关要不要自动弹本关目标：只有第一次进这一关才弹 */
  goalOnEnter: boolean
  /** 目标卡片关掉了，外面把「自动弹」消费掉，跨断点重挂载不再弹 */
  onGoalClose: () => void
  tool: Tool
  /** 电脑端左键模式：放置不覆盖已有元件、点输入元件拨 0 / 1 */
  mode: EditMode
  /** 地图框选的矩形；为空时不显示左下角的选区操作 */
  selection: Selection | null
  /** 游戏内剪贴板；只在这一关里有效 */
  clipboard: Clipboard | null
  dir: Dir
  inputs: Record<string, 0 | 1>
  history: WaveSample[]
  tick: number
  run: LevelRun | null
  /** 测试失败后的回放；有值时编辑控件变灰，波形多画参考解和检查区间 */
  trace: TraceInfo | null
  /** 参考解那几条输出线的采样 */
  refHistory: WaveSample[]
  /** 回放已经走到最后一刻，不能再往后单步 */
  traceEnd: boolean
  paused: boolean
  revision: number
  powerAt: (index: number) => number
  lockedAt: (index: number) => boolean
  outputAt: (id: string) => boolean
  onTool: (tool: Tool) => void
  onMode: () => void
  onDir: (dir: Dir) => void
  onSelect: (selection: Selection | null) => void
  onCut: () => void
  onCopy: () => void
  onPaste: () => void
  onDelete: () => void
  onCell: (index: number) => void
  onErase: (index: number) => void
  onToggleInput: (id: string) => void
  onSolution: () => void
  onExport: () => void
  onRun: () => void
  onOpenTrace: () => void
  onCloseTrace: () => void
  onPause: () => void
  onNextTick: () => void
  onPrevTick: () => void
  /** 回放时点波形跳到这一刻 */
  onSeekTick: (tick: number) => void
  onRotate: (step: 1 | -1) => void
  onLevels: () => void
}

/** 电脑端游戏界面：顶栏（右上角关卡信息 + 菜单键）+ 左侧检查器 + 右侧画布 */
export function GameDesktop({
  level,
  free,
  goalOnEnter,
  onGoalClose,
  tool,
  mode,
  selection,
  clipboard,
  dir,
  inputs,
  history,
  tick,
  run,
  trace,
  refHistory,
  traceEnd,
  paused,
  revision,
  powerAt,
  lockedAt,
  outputAt,
  onTool,
  onMode,
  onDir,
  onSelect,
  onCut,
  onCopy,
  onPaste,
  onDelete,
  onCell,
  onErase,
  onToggleInput,
  onSolution,
  onExport,
  onRun,
  onOpenTrace,
  onCloseTrace,
  onPause,
  onNextTick,
  onPrevTick,
  onSeekTick,
  onRotate,
  onLevels,
}: Props) {
  // 相机放在工作台这一层：画布负责平移，左侧滑轨直接改缩放。
  // 换关时外面的 key 会重新挂载，相机跟着回中。
  const [camera, setCamera] = useState<Camera>({ x: 0, y: 0, zoom: 1 })
  const viewport = useRef<Viewport | null>(null)
  const [menuOpen, setMenuOpen] = useState(false)
  // 第一次进这一关才自动把本关目标亮出来；自由模式没有目标，不弹
  const [infoOpen, setInfoOpen] = useState(!free && goalOnEnter)
  // 关掉卡片后就把「这次进关自动弹」消费掉：跨 1024px 断点会重挂载，
  // 不消费的话新挂载又拿 goalOnEnter 初始化 infoOpen，卡片会再弹一次
  useEffect(() => {
    if (!infoOpen) onGoalClose()
  }, [infoOpen, onGoalClose])
  const [handbookOpen, setHandbookOpen] = useState(false)

  // 回放时地图只是旁观，进回放前把选区收掉
  useEffect(() => {
    if (trace) onSelect(null)
  }, [trace, onSelect])

  // 选区快捷键：X 剪切、C 复制、V 粘贴、Delete 删除，Esc 取消选区。
  // 输入框里不抢；弹层 / 菜单打开时也不在背后动地图。
  useEffect(() => {
    if (!selection || trace || infoOpen || handbookOpen || menuOpen) return
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.repeat || event.altKey) return
      if (isTypingTarget(event.target)) return
      if (event.key === 'Escape') {
        event.preventDefault()
        onSelect(null)
        return
      }
      const action = selectionActionForKey(event.key)
      if (!action) return
      if (action === 'paste' && !clipboard) return
      event.preventDefault()
      if (action === 'cut') onCut()
      else if (action === 'copy') onCopy()
      else if (action === 'paste') onPaste()
      else onDelete()
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [
    selection,
    clipboard,
    trace,
    infoOpen,
    handbookOpen,
    menuOpen,
    onSelect,
    onCut,
    onCopy,
    onPaste,
    onDelete,
  ])

  const zoomTo = (zoom: number) => {
    const view = viewport.current
    setCamera((cam) => (view ? zoomAround(cam, view, zoom) : { ...cam, zoom: clampZoom(zoom) }))
  }

  const toggleMenu = () => {
    setInfoOpen(false)
    setMenuOpen((open) => !open)
  }

  const toggleInfo = () => {
    setMenuOpen(false)
    setInfoOpen((open) => !open)
  }

  // 点菜单外面或者按 Esc 都收起来；本关目标是一张覆盖全屏的卡片，自己管点外面和 Esc
  useEffect(() => {
    if (!menuOpen) return
    const onPointerDown = (event: PointerEvent) => {
      const target = event.target
      // 面板里的内容和开关键交给它们自己的 onClick，别在这里抢
      if (
        target instanceof Element &&
        (target.closest('.menu-panel') || target.closest('.menu-key'))
      ) {
        return
      }
      setMenuOpen(false)
    }
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setMenuOpen(false)
    }
    document.addEventListener('pointerdown', onPointerDown)
    document.addEventListener('keydown', onKeyDown)
    return () => {
      document.removeEventListener('pointerdown', onPointerDown)
      document.removeEventListener('keydown', onKeyDown)
    }
  }, [menuOpen])

  const pick = (action: () => void) => () => {
    setMenuOpen(false)
    setInfoOpen(false)
    action()
  }

  return (
    <div className="game-desktop">
      <header className="appbar">
        <div className="brand">
          <span className="brand-mark">
            <Logo size={20} />
          </span>
          <span className="brand-name">红石电路</span>
        </div>

        <div className="crumb">
          {level.no ? <span className="crumb-kicker">第 {padNo(level.no)} 关</span> : null}
          <h1 className="crumb-title">{level.name}</h1>
        </div>

        <div className="appbar-actions">
          {trace ? (
            <button
              type="button"
              className="btn icon"
              onClick={onPrevTick}
              disabled={!paused || tick <= 0}
              aria-label="上一刻"
              title={paused ? '上一刻：回放往前退一个 tick' : '暂停后才能回退'}
            >
              <PrevIcon />
            </button>
          ) : null}
          <button
            type="button"
            className="btn icon"
            onClick={onPause}
            aria-label={paused ? '继续仿真' : '暂停仿真'}
            title={paused ? '继续仿真' : '暂停仿真'}
          >
            {paused ? <PlayIcon /> : <PauseIcon />}
          </button>
          <button
            type="button"
            className="btn icon"
            onClick={onNextTick}
            disabled={!paused || traceEnd}
            aria-label={traceEnd ? '回放已到最后' : '推进一个 tick'}
            title={traceEnd ? '已到最后一刻' : '推进一个 tick'}
          >
            <StepIcon />
          </button>
          {free ? null : (
            <button type="button" className="btn primary" onClick={onRun} title="运行测试">
              测试
            </button>
          )}
          {free ? null : (
            <button
              type="button"
              className={
                run === null
                  ? 'result topbar'
                  : run.passed
                    ? 'result topbar ok'
                    : 'result topbar fail'
              }
              disabled={run === null || run.passed}
              onClick={trace ? onCloseTrace : onOpenTrace}
              aria-label={
                run === null
                  ? '测试结果：未运行'
                  : run.passed
                    ? '测试结果：全部通过'
                    : trace
                      ? '测试结果：未通过，收起回放'
                      : '测试结果：未通过，查看回放'
              }
              title={
                run === null
                  ? '还没运行测试'
                  : run.passed
                    ? '测试全部通过'
                    : trace
                      ? '收起回放，回到编辑'
                      : '测试未通过，点这里看回放波形'
              }
            >
              测试结果：
              {run === null ? <DotsIcon /> : run.passed ? <CheckIcon /> : <CrossIcon />}
            </button>
          )}

          <button
            type="button"
            className="btn icon info-key"
            aria-label="关卡信息"
            aria-haspopup="dialog"
            aria-expanded={infoOpen}
            aria-controls="level-info"
            title="关卡信息"
            onClick={toggleInfo}
          >
            <InfoIcon />
          </button>

          <button
            type="button"
            className="btn icon menu-key"
            aria-label="菜单"
            aria-haspopup="menu"
            aria-expanded={menuOpen}
            title="菜单"
            onClick={toggleMenu}
          >
            <MenuIcon />
          </button>

          {menuOpen ? (
            <div className="menu-panel" role="menu" aria-label="菜单">
              <button
                type="button"
                role="menuitem"
                className="menu-item"
                disabled={!level.solution}
                onClick={pick(onSolution)}
              >
                参考答案
              </button>
              <button
                type="button"
                role="menuitem"
                className="menu-item"
                onClick={pick(onExport)}
              >
                导出地图
              </button>
              <button
                type="button"
                role="menuitem"
                className="menu-item"
                onClick={pick(() => setHandbookOpen(true))}
              >
                查看教程
              </button>
            </div>
          ) : null}

          <button
            type="button"
            className="btn icon"
            onClick={onLevels}
            aria-label="返回选关"
            title="返回选关"
          >
            <ExitIcon />
          </button>
        </div>
      </header>

      <div className="game-grid">
        <Inspector
          level={level}
          tool={tool}
          mode={mode}
          dir={dir}
          zoom={camera.zoom}
          inputs={inputs}
          history={history}
          tick={tick}
          outputAt={outputAt}
          trace={trace}
          refHistory={refHistory}
          onTool={onTool}
          onMode={onMode}
          onDir={onDir}
          onZoom={zoomTo}
          onToggleInput={onToggleInput}
          onSeek={onSeekTick}
        />

        <main className="stage">
          <Board
            key={level.id}
            level={level}
            cells={level.cells}
            powerAt={powerAt}
            lockedAt={lockedAt}
            revision={revision}
            onCell={onCell}
            onErase={onErase}
            preview={trace ? null : tool}
            previewDir={previewDirOf(tool, dir)}
            placeMode={mode === 'place' && trace === null}
            selection={selection}
            onSelect={onSelect}
            selectable={trace === null}
            workbench={{ camera, onCamera: setCamera, onRotate: trace ? () => {} : onRotate }}
            viewportRef={viewport}
          />

          {selection && trace === null ? (
            <div className="selection-actions" role="toolbar" aria-label="选区操作">
              <button
                type="button"
                className="selection-btn"
                onClick={onCut}
                title="剪切选区里的元件和状态（X）"
                aria-keyshortcuts="X"
              >
                <span>剪切</span>
                <kbd className="selection-key">X</kbd>
              </button>
              <button
                type="button"
                className="selection-btn"
                onClick={onCopy}
                title="复制选区里的元件和状态（C）"
                aria-keyshortcuts="C"
              >
                <span>复制</span>
                <kbd className="selection-key">C</kbd>
              </button>
              <button
                type="button"
                className="selection-btn"
                onClick={onPaste}
                disabled={!clipboard}
                title={
                  clipboard
                    ? '粘贴到选区左上角，空格也会覆盖目标（V）'
                    : '剪贴板里没有东西'
                }
                aria-keyshortcuts="V"
              >
                <span>粘贴</span>
                <kbd className="selection-key">V</kbd>
              </button>
              <button
                type="button"
                className="selection-btn"
                onClick={onDelete}
                title="删除选区里的元件（Del）"
                aria-keyshortcuts="Delete"
              >
                <span>删除</span>
                <kbd className="selection-key">Del</kbd>
              </button>
            </div>
          ) : null}
        </main>
      </div>

      {infoOpen ? (
        <GoalDialog
          label={free ? '自由模式' : '本关目标'}
          text={level.brief?.trim() || '这一关还没写目标说明。'}
          onClose={() => setInfoOpen(false)}
        />
      ) : null}

      {handbookOpen ? <Handbook onClose={() => setHandbookOpen(false)} /> : null}
    </div>
  )
}
