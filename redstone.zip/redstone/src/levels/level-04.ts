import type { Cell, Level } from '../game/types'
import { cellsFrom, stateFrom } from './solution-helpers'

const cols = 10
const rows = 10
// 输入 A、B 和输出 C 由玩家自己放
const cells: (Cell | null)[] = new Array(cols * rows).fill(null)

// 参考解：两路反相器合到 C，C = A AND B
const solution = cellsFrom(cols * rows, {
  0: { type: 'input', id: 'A' },
  1: { type: 'charger', dir: 1 },
  2: { type: 'not', dir: 1 },
  12: { type: 'wire' },
  13: { type: 'charger', dir: 1 },
  14: { type: 'not', dir: 1 },
  15: { type: 'wire' },
  16: { type: 'output', id: 'C' },
  20: { type: 'input', id: 'B' },
  21: { type: 'charger', dir: 1 },
  22: { type: 'not', dir: 1 },
})

const solutionState = stateFrom({
  tick: 65,
  inputs: { A: 0, B: 0 },
  outputs: { C: 0 },
}, {
  2: 1,
  12: 3,
  13: 1,
  22: 1,
})

/** 第四关：与门，C = A AND B */
export const level04: Level = {
  id: 'level-04',
  no: 4,
  name: '与门',
  brief: 'C = A AND B：只有 A、B 同时为 1，C 才为 1，其余情况 C = 0。\n电路延迟不能超过 10 tick。',
  cols,
  rows,
  inputs: ['A', 'B'],
  outputs: ['C'],
  cells,
  solution: { cells: solution, state: solutionState },
  tests: [
    {
      name: 'A=0 B=0 → C=0',
      events: [{ tick: 0, values: { A: 0, B: 0 } }],
      checks: [{ from: 10, to: 20, outputs: { C: 0 } }],
    },
    {
      name: 'A=1 B=0 → C=0',
      events: [{ tick: 0, values: { A: 1, B: 0 } }],
      checks: [{ from: 10, to: 20, outputs: { C: 0 } }],
    },
    {
      name: 'A=0 B=1 → C=0',
      events: [{ tick: 0, values: { A: 0, B: 1 } }],
      checks: [{ from: 10, to: 20, outputs: { C: 0 } }],
    },
    {
      name: 'A=1 B=1 → C=1',
      events: [{ tick: 0, values: { A: 1, B: 1 } }],
      checks: [{ from: 10, to: 20, outputs: { C: 1 } }],
    },
  ],
}
