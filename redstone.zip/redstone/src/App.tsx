import { useCallback, useEffect, useReducer, useRef, useState } from 'react'
import { hasDirection, runLevel, Simulation, testSpan, type LevelRun } from './game/sim'
import type { Cell, Dir, Level, TestCase } from './game/types'
import { LEVELS } from './levels'
import { freeLevel, isFreeLevel } from './levels/free'
import { defaultTool } from './ui/tools'
import { rotateDir } from './ui/keyboard'
import { download, mapFileName, mapJson } from './ui/export'
import { solutionMap } from './ui/solution'
import { pushSample, waveSample, type WaveSample } from './ui/waveform'
import { checksOf, pairsOf, refLevelOf, replaySimTo, replayStep, replayTo, type TraceInfo } from './ui/trace'
import type { Tool } from './ui/tools'
import { editAction, type EditMode } from './ui/edit-mode'
import {
  captureSelection,
  eraseSelection,
  hasClipboardContent,
  pasteCircuitState,
  pasteClipboard,
  type Clipboard,
  type Selection,
} from './ui/selection'
import { DESKTOP_QUERY, useMediaQuery } from './ui/useMediaQuery'
import {
  isGoalSeen,
  loadProgress,
  markGoalSeen,
  markLevelCleared,
  saveProgress,
  type Progress,
} from './ui/progress'
import { StartScreen } from './ui/StartScreen'
import { Handbook } from './ui/Handbook'
import { LevelSelect } from './ui/LevelSelect'
import { GameDesktop } from './ui/GameDesktop'
import { GameMobile } from './ui/GameMobile'
import './App.css'

const INITIAL_DIR: Dir = 1

/** 编辑器里仿真每 tick 的间隔：4 tick/s */
const TICK_MS = 250

type Screen = 'start' | 'levels' | 'game'

interface Editing {
  level: Level
  sim: Simulation
  /** 检查器波形图用的采样，只保留最近一段 tick；和仿真一起更新，改元件时当拍就能覆盖 */
  history: WaveSample[]
}

/**
 * 测试没通过后的回放：按点「测试」那一刻的快照重跑这一组测试，输入由测试事件驱动，
 * 玩家电路和参考解一起走；退出时把进来前的编辑状态原样还回去。
 */
interface Replay {
  info: TraceInfo
  test: TestCase
  /** 整组测试的波形：进回放时一次跑完存下来，红线只当播放头，不跟着重画 */
  history: WaveSample[]
  refHistory: WaveSample[]
  /** 这次测试的起跑仿真（快照，tick 归零）；「上一刻」也从它重跑 */
  start: Simulation
  saved: Editing & { inputs: Record<string, 0 | 1>; paused: boolean }
  lastTick: number
}

const initial = (): Editing => {
  const level = { ...LEVELS[0], cells: LEVELS[0].cells.slice() }
  const sim = new Simulation(level)
  return { level, sim, history: [waveSample(level, sim)] }
}

/**
 * 上一次「运行测试」的结果，以及点下去那一刻现场电路和状态的快照。
 * 测试和回放都从这份快照起跑：编辑器之后继续跑、继续改，都不会影响已经跑出来的结果。
 * 结果不跟编辑器联动，改元件、拨输入都不会把它清掉，只有再点一次「测试」才替换。
 */
interface RunState {
  result: LevelRun
  snapshot: Simulation
}

/**
 * 回放的起跑仿真：拿「测试」那一刻的快照状态，tick 归零。
 * 回放的横轴从 0 数、测试事件也按 0 起的 tick 排，但电路内部状态（反相器、中继器、
 * 导线电平和输入）保持快照里的样子，放出来的就是当时那次测试。
 */
function replayStart(snapshot: Simulation): Simulation {
  const sim = new Simulation(snapshot.level)
  sim.restore({ ...snapshot.circuitState(), tick: 0 })
  return sim
}

export default function App() {
  const [{ level, sim, history }, setEditing] = useState<Editing>(initial)
  const [tool, setTool] = useState<Tool>({ type: 'wire' })
  // 再点一次「交互」还原成上一次选的元件（手机端交互时元件栏换成了波形图）
  const lastTool = useRef<Tool>({ type: 'wire' })
  // 电脑端左键模式：默认覆盖（放元件直接替换已有元件），切到放置才会只填空格
  const [mode, setMode] = useState<EditMode>('overwrite')
  const [dir, setDir] = useState<Dir>(INITIAL_DIR)
  // 最近一次「运行测试」的结果：改电路、拨输入都不清，点「测试」或换关才变
  const [run, setRun] = useState<RunState | null>(null)
  // 测试没通过后点结果按钮进入的回放：元件栏换成波形图，电路从测试快照起跑
  const [replay, setReplay] = useState<Replay | null>(null)
  // 编辑器里手动开关的输入
  const [inputs, setInputs] = useState<Record<string, 0 | 1>>({})
  const [menuOpen, setMenuOpen] = useState(false)
  const [screen, setScreen] = useState<Screen>('start')
  // 存在浏览器里的关卡进度：已通关的关卡、已经自动弹过目标的关卡
  const [progress, setProgress] = useState<Progress>(loadProgress)
  // 这次进入关卡要不要自动弹本关目标；只有第一次进这一关才弹
  const [goalOnEnter, setGoalOnEnter] = useState(false)
  // 目标卡片关掉后由游戏界面通知这里消费掉：跨 1024px 断点会换布局重挂载，
  // 不清掉的话新挂载的界面会拿它再初始化一次，卡片又弹出来
  const dismissGoal = useCallback(() => setGoalOnEnter(false), [])
  // 首页的「查看教程」：教程页和游戏内菜单里的是同一个，进游戏前也能先看一眼规则
  const [handbookOpen, setHandbookOpen] = useState(false)
  // 仿真在后台推进，只在画面有变化时重绘
  const [version, repaint] = useReducer((n: number) => n + 1, 0)
  // 调试用：暂停自动 tick
  const [paused, setPaused] = useState(false)
  // 电脑端地图框选，以及同一次进关里共用的剪贴板；退出关卡时一起清掉
  const [selection, setSelection] = useState<Selection | null>(null)
  const [clipboard, setClipboard] = useState<Clipboard | null>(null)
  // 自由模式没有关卡号、端口和测试，界面上要把这些入口收起来
  const free = isFreeLevel(level)
  const isDesktop = useMediaQuery(DESKTOP_QUERY)
  // 手机菜单只在手机布局里算数；拖到桌面宽度时不应该把仿真停住
  const mobileMenuOpen = menuOpen && !isDesktop
  // 回放最后一刻就是采样到 lastTick 的那一格，再往后没有检查了
  const traceEnd = replay !== null && sim.tick >= replay.lastTick

  // 手机端的「交互」是元件栏里的工具；拖到电脑端后换成模式按钮，
  // 别留下一个电脑端没有入口再退出的交互工具
  useEffect(() => {
    if (!isDesktop) return
    setTool((prev) => (prev === 'interact' ? lastTool.current : prev))
  }, [isDesktop])

  /**
   * 定时器只建一次：改元件会重建仿真，如果定时器依赖 sim，每放一格都会被清掉重建，
   * 计数又从 0 开始——一直连点 / 拖动画布时 tick 就永远到不了 250ms，看起来是卡住了。
   * 这里让定时器读 ref 里的最新仿真，放东西不会打断节拍。
   */
  const simRef = useRef(sim)
  useEffect(() => {
    simRef.current = sim
  }, [sim])

  /** 给波形图补一帧当前 tick 的采样；电脑端检查器和手机端「交互」面板都读它 */
  const record = useCallback(() => {
    setEditing((prev) => ({
      ...prev,
      history: pushSample(prev.history, waveSample(prev.level, prev.sim)),
    }))
  }, [])

  /** 走一个 tick：回放时先把这一 tick 的测试事件拨上，玩家电路和参考解一起走 */
  const stepOnce = () => {
    if (replay) {
      // 这组测试已经跑完，回放停在最后
      if (sim.tick >= replay.lastTick) {
        setPaused(true)
        return
      }
      // 整组波形进回放时就跑完了，这儿只推仿真，波形和红线都不用重采样
      replayStep(replay.test, sim)
      setInputs(sim.inputValues())
      // 这组测试跑完就停住
      if (sim.tick >= replay.lastTick) setPaused(true)
      repaint()
      return
    }
    // step() 直接返回画面有没有变化，不用前后各拍一次快照
    const changed = simRef.current.step()
    record()
    if (changed) repaint()
  }

  // 定时器只建一次，每帧读最新的 stepOnce，换关 / 改元件都不会打断节拍
  const stepRef = useRef(stepOnce)
  useEffect(() => {
    stepRef.current = stepOnce
  })

  useEffect(() => {
    if (paused || mobileMenuOpen || screen !== 'game') return
    const timer = setInterval(() => stepRef.current(), TICK_MS)
    return () => clearInterval(timer)
  }, [paused, mobileMenuOpen, screen])

  // 鼠标点完按钮别留下焦点：焦点在按钮上时再按键盘，浏览器会描一圈焦点框
  useEffect(() => {
    let pointerType = 'mouse'
    const onPointerDown = (event: PointerEvent) => {
      pointerType = event.pointerType
    }
    const onMouseDown = (event: MouseEvent) => {
      // 只有鼠标点击才处理，别影响触摸 / 触控笔
      if (pointerType !== 'mouse' || event.button !== 0) return
      // 不让按钮拿到焦点；已经拿到的也放掉，焦点框只留给 Tab 键
      if (event.target instanceof Element && event.target.closest('button')) event.preventDefault()
      if (document.activeElement instanceof HTMLElement) document.activeElement.blur()
    }
    document.addEventListener('pointerdown', onPointerDown, true)
    document.addEventListener('mousedown', onMouseDown)
    return () => {
      document.removeEventListener('pointerdown', onPointerDown, true)
      document.removeEventListener('mousedown', onMouseDown)
    }
  }, [])

  const nextTick = () => {
    if (!paused) return
    stepOnce()
  }

  // 画布只按需取可见格子的状态，不再每帧生成整张 powers
  const powerAt = useCallback((index: number) => sim.powerAt(index), [sim])
  const lockedAt = useCallback((index: number) => sim.isLocked(index), [sim])
  // 行尾显示「现在」，和地图一样读实时输出；`output()` 是测试用的 tick 开头采样
  const outputAt = useCallback((id: string) => sim.liveOutput(id), [sim])

  /** 改一格元件并重建仿真；锁住的格子不动 */
  const writeCell = (index: number, next: Cell | null) => {
    setEditing((prev) => {
      const cells = prev.level.cells.slice()
      if (cells[index]?.locked) return prev
      if (next === null && !cells[index]) return prev
      cells[index] = next
      const level = { ...prev.level, cells }
      const sim = new Simulation(level, prev.sim)
      // 重建后把手动开关的输入接着用
      sim.setInputs(inputs)
      // 这一 tick 的输出已经跟着电路变了，采样要覆盖成新值，
      // 只改最后一格的画面没用：过一刻它就成了历史，又会显示回旧电平
      return { level, sim, history: pushSample(prev.history, waveSample(level, sim)) }
    })
    setReplay(null)
  }

  /** 把选区里的元件和状态收进剪贴板；锁定元件（例如第一关的输入 / 输出）按空格处理 */
  const copySelection = () => {
    if (!selection || replay) return
    const clip = captureSelection(
      level.cells,
      level.cols,
      level.rows,
      selection,
      (index) => sim.powerAt(index),
    )
    setClipboard(hasClipboardContent(clip) ? clip : null)
  }

  /** 删除选区里的元件；锁定元件不动 */
  const removeSelection = (rect: Selection) => {
    setEditing((prev) => {
      const result = eraseSelection(prev.level.cells, prev.level.cols, rect)
      if (!result.changed) return prev
      const next = { ...prev.level, cells: result.cells }
      const nextSim = new Simulation(next, prev.sim)
      // 重建后把手动开关的输入接着用
      nextSim.setInputs(inputs)
      return {
        level: next,
        sim: nextSim,
        history: pushSample(prev.history, waveSample(next, nextSim)),
      }
    })
    setReplay(null)
  }

  /** 剪切：先复制，再删掉选区内能删的元件 */
  const cutSelection = () => {
    if (!selection || replay) return
    const clip = captureSelection(
      level.cells,
      level.cols,
      level.rows,
      selection,
      (index) => sim.powerAt(index),
    )
    setClipboard(hasClipboardContent(clip) ? clip : null)
    removeSelection(selection)
  }

  const deleteSelection = () => {
    if (!selection || replay) return
    removeSelection(selection)
  }

  /** 粘贴到当前选区左上角：空格也覆盖目标，越界丢弃，锁定目标格不动 */
  const pasteSelection = () => {
    if (!selection || !clipboard || replay) return
    const result = pasteClipboard(level.cells, level.cols, level.rows, selection, clipboard)
    if (!result.changed) return

    const state = sim.circuitState()
    const next = { ...level, cells: result.cells }
    const nextSim = new Simulation(next, sim)
    // 保留现场状态，再把剪贴板里每格的激活状态盖到贴上去的位置
    const pasted = pasteCircuitState(state, inputs, result.placed)
    nextSim.restore({ ...state, ...pasted })
    setEditing({
      level: next,
      sim: nextSim,
      history: pushSample(history, waveSample(next, nextSim)),
    })
    setInputs(pasted.inputs)
    setReplay(null)
  }

  /** 选元件；「交互」再点一次就回到上一次选的元件 */
  const pickTool = useCallback((next: Tool) => {
    if (next === 'interact') {
      setTool((prev) => (prev === 'interact' ? lastTool.current : 'interact'))
      return
    }
    lastTool.current = next
    setTool(next)
  }, [])

  /** 切换一个输入元件的 0 / 1；桌面端左侧面板和「交互」工具都走这里 */
  const toggleInput = (id: string) => {
    const next: Record<string, 0 | 1> = { ...inputs, [id]: inputs[id] ? 0 : 1 }
    setInputs(next)
    sim.setInputs(next)
    setReplay(null)
    record()
    repaint()
  }

  const handleCell = (index: number) => {
    // 回放时地图只是旁观，别把回放的电路改了
    if (replay) return
    // 手机端的「交互」工具：点输入元件开关它
    if (tool === 'interact') {
      const cell = level.cells[index]
      if (cell?.type === 'input' && cell.id) toggleInput(cell.id)
      return
    }
    // 删除工具在两种模式下都直接删，不受「不覆盖」限制
    if (tool === 'erase') {
      writeCell(index, null)
      return
    }
    // 手机端没有模式切换，仍然保持原来的放置 / 覆盖
    const action = editAction(isDesktop ? mode : 'overwrite', level.cells[index])
    if (action.type === 'toggle') {
      toggleInput(action.id)
      return
    }
    if (action.type === 'blocked') return

    const cell: Cell = {
      type: tool.type,
      dir: hasDirection(tool.type) ? dir : undefined,
      id: tool.id,
    }
    writeCell(index, cell)
  }

  /** 右键删除：只删格子，元件栏选中的元件不变 */
  const handleErase = (index: number) => {
    if (replay) return
    writeCell(index, null)
  }

  /** 参考答案：把布局和保存时的电路状态一起盖上去，玩家当前搭的会被冲掉 */
  const applySolution = () => {
    const solution = solutionMap(level)
    if (!solution) return
    const next = { ...level, cells: solution.cells }
    const sim = new Simulation(next)
    sim.restore(solution.state)
    // 参考解把 tick 拨回去了，旧波形接不上，从这个 tick 重新记
    setEditing({ level: next, sim, history: [waveSample(next, sim)] })
    setInputs(solution.state.inputs)
    // 地图整个换了，旧选区不再对应任何东西
    setSelection(null)
    setReplay(null)
    setMenuOpen(false)
  }

  const startLevel = (next: Level) => {
    const level = { ...next, cells: next.cells.slice() }
    const sim = new Simulation(level)
    // 第一次进这一关才自动弹目标；一进来就记下，之后从选关页再进来不再弹
    const firstVisit = !isFreeLevel(level) && !isGoalSeen(progress, level.id)
    if (firstVisit) {
      const seen = markGoalSeen(progress, level.id)
      setProgress(seen)
      saveProgress(seen)
    }
    setGoalOnEnter(firstVisit)
    setEditing({ level, sim, history: [waveSample(level, sim)] })
    // 换关后元件选择也回到这关的默认元件，模式回到默认的覆盖，别把上一关的选择带过来
    lastTool.current = { type: defaultTool(level) }
    setTool(lastTool.current)
    setMode('overwrite')
    setDir(INITIAL_DIR)
    setInputs({})
    // 换关：上一关的结果不属于这一关
    setRun(null)
    setReplay(null)
    setPaused(false)
    setMenuOpen(false)
    // 剪贴板只在这一关里有效；换关 / 退出时清掉
    setSelection(null)
    setClipboard(null)
    setScreen('game')
  }

  /**
   * 点「测试结果：×」进入回放：电路从点「测试」那一刻的快照起跑，重跑第一组
   * 没通过的测试，输入由测试事件驱动，元件栏换成波形图。整组波形一进来就画满，
   * 红线只当播放头，地图跟着「继续」/「下一刻」走。
   */
  const openTrace = () => {
    if (!run || run.result.passed || replay) return
    // 回放按「测试」那一刻的快照放：电路、输入和内部状态都是当时那份，
    // 编辑器之后改了电路也不会影响它；退出回放时再把当前这块电路还回来
    const tested = run.snapshot.level
    const index = run.result.outcomes.findIndex((outcome) => !outcome.passed)
    const test = tested.tests[Math.max(0, index)]
    if (!test) return
    const refLevel = refLevelOf(tested)
    const lastTick = testSpan(test)
    // 从快照起跑，把玩家的输入 / 输出和参考解的输出一整条都存下来；
    // 起点那份仿真单独跑一次（steps = 0），用来把地图停在第一刻
    const start = replayStart(run.snapshot)
    const cold = replayTo(tested, test, refLevel, 0, start)
    const whole = replayTo(tested, test, refLevel, lastTick, start)
    setReplay({
      info: {
        name: test.name ?? '测试',
        checks: checksOf(test),
        pairs: pairsOf(test),
        lastTick,
      },
      test,
      history: whole.history,
      refHistory: whole.refHistory,
      start,
      lastTick,
      saved: { level, sim, history, inputs, paused },
    })
    setEditing({ level: tested, sim: cold.sim, history: cold.history })
    setInputs(cold.sim.inputValues())
    // 回放里不能编辑，选区也收掉
    setSelection(null)
    setPaused(true)
    repaint()
  }

  /** 退出回放：把进来之前的电路、输入和暂停状态原样还回去；不在回放里返回 null */
  const leaveTrace = () => {
    if (!replay) return null
    const { saved } = replay
    setEditing({ level: saved.level, sim: saved.sim, history: saved.history })
    setInputs(saved.inputs)
    setPaused(saved.paused)
    setReplay(null)
    return saved
  }

  /** 再点一次结果按钮：收起回放 */
  const closeTrace = () => {
    if (leaveTrace()) repaint()
  }

  /** 上一刻：从测试快照重跑到前一个 tick；整组波形不动，只有红线往左退一格 */
  const prevTick = () => {
    if (!replay) return
    // 波形和参考解已经整组存下了，往后退只重跑玩家那份，把地图停到前一刻；
    // 和进回放一样从测试快照起跑，状态才和结果对得上
    const back = replaySimTo(replay.test, Math.max(0, sim.tick - 1), replay.start)
    setEditing((prev) => ({ ...prev, sim: back }))
    setInputs(back.inputValues())
    repaint()
  }

  /**
   * 点回放波形：从测试快照重跑到点到的那一格，地图、输入 / 输出和参考解的当前值
   * 一起停到那一刻。点完就暂停，方便对照着看；波形本身不动，只挪红线。
   * 最后一格就是测试结束，夹在 0–lastTick 之间。
   */
  const seekTick = (target: number) => {
    if (!replay) return
    const to = Math.max(0, Math.min(target, replay.lastTick))
    if (to === sim.tick) {
      setPaused(true)
      return
    }
    const next = replaySimTo(replay.test, to, replay.start)
    setEditing((prev) => ({ ...prev, sim: next }))
    setInputs(next.inputValues())
    setPaused(true)
    repaint()
  }

  const togglePause = () => setPaused((value) => !value)

  /**
   * 点「测试」：先把现场这块电路和它当前的仿真状态 fork 一份快照，再拿快照跑这一关的测试。
   * 编辑器之后接着跑、接着改都影响不到这次结果；点和测之间也不会插进别的状态——
   * 按一下就立刻拿眼前这一份去测。
   */
  const runTests = () => {
    // 回放中按「测试」：先退出回放，再拿回来那份电路重新测
    const saved = leaveTrace()
    const live = saved?.sim ?? sim
    const snapshot = live.fork()
    const result = runLevel(snapshot.level, snapshot)
    setRun({ result, snapshot })
    // 全部通过就记下这一关通关；自由模式没有测试，也不会进来
    if (result.passed && !free) {
      const cleared = markLevelCleared(progress, level.id)
      setProgress(cleared)
      saveProgress(cleared)
    }
    if (saved) repaint()
  }

  /** 选关页的「自由模式」：20×20 空白沙盒，没有输入输出和测试 */
  const startFree = () => startLevel(freeLevel)

  const goHome = () => {
    setMenuOpen(false)
    setHandbookOpen(false)
    setSelection(null)
    setClipboard(null)
    setScreen('start')
  }

  const goLevels = () => {
    setMenuOpen(false)
    setHandbookOpen(false)
    setSelection(null)
    setClipboard(null)
    setScreen('levels')
  }

  if (screen === 'start') {
    return (
      <>
        <StartScreen onStart={goLevels} onHandbook={() => setHandbookOpen(true)} />
        {handbookOpen ? <Handbook onClose={() => setHandbookOpen(false)} /> : null}
      </>
    )
  }

  if (screen === 'levels') {
    return (
      <LevelSelect
        levels={LEVELS}
        cleared={progress.cleared}
        onSelect={startLevel}
        onFree={startFree}
        onHome={goHome}
      />
    )
  }

  if (isDesktop) {
    return (
      <GameDesktop
        key={level.id}
        level={level}
        free={free}
        goalOnEnter={goalOnEnter}
        onGoalClose={dismissGoal}
        tool={tool}
        mode={mode}
        selection={selection}
        clipboard={clipboard}
        dir={dir}
        inputs={inputs}
        history={replay ? replay.history : history}
        tick={sim.tick}
        run={run?.result ?? null}
        trace={replay?.info ?? null}
        refHistory={replay ? replay.refHistory : []}
        traceEnd={traceEnd}
        paused={paused}
        revision={version}
        powerAt={powerAt}
        lockedAt={lockedAt}
        outputAt={outputAt}
        onTool={pickTool}
        onMode={() => setMode((value) => (value === 'place' ? 'overwrite' : 'place'))}
        onDir={setDir}
        onSelect={setSelection}
        onCut={cutSelection}
        onCopy={copySelection}
        onPaste={pasteSelection}
        onDelete={deleteSelection}
        onCell={handleCell}
        onErase={handleErase}
        onToggleInput={toggleInput}
        onSolution={applySolution}
        onExport={() => download(mapFileName(level), mapJson(level, sim))}
        onRun={runTests}
        onOpenTrace={openTrace}
        onCloseTrace={closeTrace}
        onPause={togglePause}
        onNextTick={nextTick}
        onPrevTick={prevTick}
        onSeekTick={seekTick}
        onRotate={(step) => {
          if (!replay) setDir((value) => rotateDir(value, step))
        }}
        onLevels={goLevels}
      />
    )
  }

  return (
    <GameMobile
      level={level}
      free={free}
      goalOnEnter={goalOnEnter}
      onGoalClose={dismissGoal}
      tool={tool}
      dir={dir}
      run={run?.result ?? null}
      paused={paused}
      revision={version}
      menuOpen={mobileMenuOpen}
      history={replay ? replay.history : history}
      tick={sim.tick}
      inputs={inputs}
      powerAt={powerAt}
      lockedAt={lockedAt}
      outputAt={outputAt}
      trace={replay?.info ?? null}
      refHistory={replay ? replay.refHistory : []}
      traceEnd={traceEnd}
      onTool={pickTool}
      onDir={setDir}
      onCell={handleCell}
      onErase={handleErase}
      onToggleInput={toggleInput}
      onRun={runTests}
      onOpenTrace={openTrace}
      onCloseTrace={closeTrace}
      onPause={togglePause}
      onNextTick={nextTick}
      onPrevTick={prevTick}
      onSeekTick={seekTick}
      onMenuToggle={() => setMenuOpen((open) => !open)}
      onContinue={() => setMenuOpen(false)}
      onSolution={applySolution}
      onExport={() => download(mapFileName(level), mapJson(level, sim))}
      onLevels={goLevels}
    />
  )
}
